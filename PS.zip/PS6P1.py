start=1
stop=25
while start<=stop:
  rem=start % 2
  if rem != 0:
    print(start)
  start=start+1
  
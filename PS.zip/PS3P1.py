score1 = float(input("Enter the first exam score (60%): "))
score2 = float(input("Enter the second exam score (40%): "))
total_score = (score1 * 0.6) + (score2 * 0.4)
print(f"Total Score: {total_score:.2f}")
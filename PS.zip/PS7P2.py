for number in range(1, 26):
  if number % 2 != 0:
      print(number)
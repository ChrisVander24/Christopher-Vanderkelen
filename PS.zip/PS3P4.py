first_name = input("Enter your first name: ")
steps_walked = int(input("Enter the number of steps: "))
calories_burned = steps_walked * 0.25
print(f"{first_name}, you burned {calories_burned} calories.")
start = int(input("Enter start value: "))
stop = int(input("Enter stop value: "))
increment = int(input("Enter increment value: "))
while start<=stop:
  print(start)
  start=start+increment